#include <iostream>
#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#define NAME "ps.cc"
using namespace std;
int main()
{
	setlocale(LC_ALL, "rus");
	int ps;
	char buf[80];
	read(open(NAME, 0), buf, sizeof(buf));
	system(buf);
	close(ps);
	unlink(NAME); return 0;
}