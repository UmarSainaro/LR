#include <iostream>
#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#define NAME "ps.cc"
using namespace std;
int main()
{
	setlocale(LC_ALL, "rus");
	char text[80];
	int ps;
	cout << "Enter command:" << endl;
	cin >> text;
	mkfifo(NAME, S_IFIFO | S_IRWXU | S_IRWXG | S_IRWXO);
	if ((ps = open(NAME, O_WRONLY)) == -1) {
		perror("Error");
		return 1;
	}
	write(ps, text, strlen(text));
	cout << "Записано в file.txt";
	system(text);
	close(ps);
	return 0;
}