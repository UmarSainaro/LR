    #include <signal.h>
    #include <fcntl.h>  
    #include <stdio.h>
    #include <stdlib.h>
    #include <string.h>
    #include <sys/stat.h>
     
    int sig     = SIGUSR1;  
    int sigrecvd    = 0;        
    int nbytes      = 10;
    char    bytes[2]    = "23";     
    int pid, cpid2, cpid3, ppid;    
    int fd;             
    int i,j;
    struct  timeval ttwait = {1,0};     
    char    outfile[128]    = "out.txt";    
     
    void sig_handler(int signal) {
        int pid;
        if (signal == sig ) 
            sigrecvd++;
        pid=getpid();   
        fprintf(stderr, "%u: signal %u recieved.\n",pid,signal);
    }
     
    void run_child (int pnum)
    {
        pid=getpid();   
        fprintf(stderr, "Process %u pid is %u\n",pnum,pid );
        ppid = getppid();
        fprintf(stderr, "%u: stop until signal...\n",pid);
        for (;sigrecvd<1;) 
        {
            select(0,NULL,NULL,NULL,&ttwait);   
        }
        fprintf(stderr, "%u: writing %u bytes to %s...\n",pid,nbytes,outfile);
        
        for (j=0;j<nbytes;j++)
            write(fd, bytes-2+pnum, 1);
        fprintf(stderr, "%u: ..write done, send signal %u to parent (%u) and terminate.\n",pid,sig,ppid);
        kill(ppid,sig);
        exit(0);    
    }
     
    int main (int argc, char **argv)
    {
     
    
    if (1 < argc)
        (void)strcpy(outfile,argv[1]);
     
    
    if (2 < argc)
        if ( 1 != sscanf(argv[2],"%u",&nbytes) )
            fprintf(stderr, "N bytes is not %%u, ignored.\n");
     
    fprintf(stderr, "N bytes set to [%u].\n",nbytes);
    fprintf(stderr, "Outfile set to [%s].\n",outfile);
     
   
    if (SIG_ERR == signal(sig,sig_handler))
    {
        fprintf(stderr, "cant set signal %u handler - terminated.\n",sig);
        exit(-1);
    }
     
    
    if (0 > ( fd = open(outfile,O_RDWR|O_APPEND|O_CREAT,0644)))
    {
        fprintf(stderr, "Process 1: cant open() file %s.\n",outfile);
        exit(-1);
    }
     
    
    if (0 == (cpid2 = fork()) ) 
        run_child(2);
     
    if (0 == (cpid3 = fork()) )
        run_child(3);
     
    pid=getpid();   
    fprintf(stderr, "Process 1 pid is %u\n",pid );
     
   
    select(0,NULL,NULL,NULL,&ttwait);
    kill(cpid2,sig);
    kill(cpid3,sig);
     
    for (;sigrecvd<2;)  
        select(0,NULL,NULL,NULL,&ttwait);
    fprintf(stderr, "%u: all chldren done, print outfile %s: ",pid,outfile );
    lseek(fd,0,SEEK_SET);
    bytes[1]='\0';
    for (j=1;j>0;)
    {
        j=read(fd, bytes, 1);
        fprintf(stderr, "%s",bytes);
    }
    fprintf(stderr, "\n");
    if (j<0)
        fprintf(stderr, "%u: error read file %s\n",pid,outfile);
     
    exit(0);
     
    } 